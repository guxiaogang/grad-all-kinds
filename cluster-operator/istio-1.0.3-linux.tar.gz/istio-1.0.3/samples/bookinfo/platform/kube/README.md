See the [Bookinfo guide](https://istio.io/docs/guides/bookinfo.html) in Istio
docs for instructions on how to run this demo application.
